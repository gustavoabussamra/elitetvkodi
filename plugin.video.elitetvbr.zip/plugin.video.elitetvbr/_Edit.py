import xbmcaddon

MainBase = 'http://bit.ly/2JiHqkX'
addon = xbmcaddon.Addon('plugin.video.elitetvbr')